package com.example.pi_ease.DAO.Entities;

public enum TypeCL {

    TRANSACTION,CREDIT,ACCOUNT
}

package com.example.pi_ease.DAO.Entities;

public enum TypeCheck {
    Uncrossed,Crossed_out
}

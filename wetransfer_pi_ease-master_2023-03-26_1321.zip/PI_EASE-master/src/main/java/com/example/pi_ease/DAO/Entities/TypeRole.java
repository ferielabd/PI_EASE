package com.example.pi_ease.DAO.Entities;



public enum TypeRole {

    ADMIN,CLIENT,INVESTOR,AGENT_SALES,INVESTORNP,INVESTORP;
}

package com.example.pi_ease.DAO.Entities;

public enum TypeAccount {
    SAVING_ACCOUNT,CURRENT_ACCOUNT
}

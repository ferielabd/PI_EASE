package com.example.pi_ease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiEaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
